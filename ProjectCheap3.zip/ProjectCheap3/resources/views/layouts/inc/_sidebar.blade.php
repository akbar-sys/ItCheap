<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<nav>
					<ul class="nav">
						<li><a href="/dashboard" class=""><i class="lnr lnr-home"></i> <span>Dashboard</span></a></li>
						<li><a href="/produk" class=""><i class="lnr lnr-cart"></i> <span>Product</span></a></li>
					</ul>
				</nav>
			</div>
		</div>