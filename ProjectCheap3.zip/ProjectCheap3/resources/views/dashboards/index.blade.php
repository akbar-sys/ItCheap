@extends('layouts.master')

@section('konten')  
	<div class="main">
        <div class="main-content">
            <div class="container-fluid">
            	<div class="row">
					@foreach($data_product as $product)
                    <div class="col-md-12">
                    <div class="panel">
						<div class="panel-heading">
				            <h2 class="page-header">{{$product->nama_produk}}</h2>
								<div class="content">
								   	<div class="container-fluid">
								       	<div class="row">
								      		<div class="col-lg-6">
									            <div class="card">
									              	<div class="card-body">
										                <h3>{{$product->ecommerce}}
										                	<small> {{$product->harga}}</small>
										                </h3>
									                	<p>{{$product->deskripsi}}</p>
									               		<a href="{{$product->url}}" class="card-link">Card link</a>
									             	</div>
									            </div>
									       	</div>
									    </div>
									</div>
								</div>
				            </div>
				        </div>
				    </div>
				    @endforeach
				</div>
			</div>
        </div>
    </div>

@stop