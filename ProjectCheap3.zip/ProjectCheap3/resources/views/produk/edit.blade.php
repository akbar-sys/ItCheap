@extends('layouts.master')

@section('konten')
    <div class="main">
        <div class="main-content">
            <div class="container-fluid">
            <h1> Edit Data Produk</h2>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel">
                            <form action="/produk/{{$product->id_produk}}/update" method="POST">
                            {{csrf_field()}}
                                    <div class="mb-3">
                                        <label class="form-label">Nama Produk</label>
                                        <input name="nama_produk" type="text" class="form-control" placeholder="Nama Produk" value="{{$product->nama_produk}}" >
                                    </div>
                                    <div class="mb-3">
                                            <label class="form-label">Deskripsi</label>
                                            <input name="deskripsi" type="text" class="form-control" placeholder="Deskripsi" value="{{$product->deskripsi}}">
                                    </div>
                                    <div class="mb-3">
                                            <label class="form-label">Harga</label>
                                            <input name="harga" type="text" class="form-control" placeholder="Harga" value="{{$product->harga}}">
                                    </div>
                                    <div class="mb-3">
                                            <label class="form-label">E-Commerce</label>
                                            <input name="ecommerce" type="text" class="form-control" placeholder="E-Commerce" value="{{$product->ecommerce}}">
                                    </div>
                                    <div class="mb-3">
                                            <label class="form-label">URL</label>
                                            <input name="url" type="text" class="form-control" placeholder="URL" value="{{$product->url}}" >
                                    </div>
                                    <div class="modal-footer">
                                    <a href="/produk" class='btn btn-secondary'>Close</a>
                                    <button type="submit" class="btn btn-primary">Update</button>
                            </form>
						    </div>
						</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop