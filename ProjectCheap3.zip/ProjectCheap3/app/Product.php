<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $table = 'product';
    protected $fillable = ['id_produk','nama_produk','deskripsi','harga','ecommerce','url'];
    protected $primaryKey = 'id_produk';

}
