<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(){
        return view('dashboards.index');
    }
    public function data(){
        $data_product = \App\Product::all();
        return view('dashboards.index',['data_product' => $data_product]);
    }
}
