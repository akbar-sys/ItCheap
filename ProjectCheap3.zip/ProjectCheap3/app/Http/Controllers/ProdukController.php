<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProdukController extends Controller
{
    public function index(){
        $data_product = \App\Product::all();
        return view('produk.index',['data_product' => $data_product]);
    }

    public function create(Request $request){
        \App\Product::create($request->all());
        return redirect('/produk');
    }

    public function edit($id_produk){
        $product = \App\Product::find($id_produk);
        return view('produk/edit',['product' => $product]);
    }

    public function update(Request $request,$id_produk){
        $product = \App\Product::find($id_produk);
        $product->update($request->all());
        return redirect('/produk');
    }

    public function delete($id_produk){
        $product = \App\Product::find($id_produk);
        $product->delete();
        return redirect('/produk');
    }
}
