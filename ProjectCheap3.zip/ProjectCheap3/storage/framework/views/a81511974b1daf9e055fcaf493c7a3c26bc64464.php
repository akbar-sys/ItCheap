<?php $__env->startSection('konten'); ?>  
	<div class="main">
        <div class="main-content">
            <div class="container-fluid">
            	<div class="row">
					<?php $__currentLoopData = $data_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12">
                    <div class="panel">
						<div class="panel-heading">
				            <h2 class="page-header"><?php echo e($product->nama_produk); ?></h2>
								<div class="content">
								   	<div class="container-fluid">
								       	<div class="row">
								      		<div class="col-lg-6">
									            <div class="card">
									              	<div class="card-body">
										                <h3><?php echo e($product->ecommerce); ?>

										                	<small> <?php echo e($product->harga); ?></small>
										                </h3>
									                	<p><?php echo e($product->deskripsi); ?></p>
									               		<a href="<?php echo e($product->url); ?>" class="card-link">Card link</a>
									             	</div>
									            </div>
									       	</div>
									    </div>
									</div>
								</div>
				            </div>
				        </div>
				    </div>
				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>