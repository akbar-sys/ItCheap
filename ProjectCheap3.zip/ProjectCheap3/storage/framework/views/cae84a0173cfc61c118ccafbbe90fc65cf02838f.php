<!doctype html>
<html lang="en">

<head>
	<title>iTCheap</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<!-- VENDOR CSS -->
	<link rel="stylesheet" href="<?php echo e(asset('Klorofil/assets/vendor/bootstrap/css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('Klorofil/assets/vendor/font-awesome/css/font-awesome.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('Klorofil/assets/vendor/linearicons/style.css')); ?>">
	<!-- MAIN CSS -->
	<link rel="stylesheet" href="<?php echo e(asset('Klorofil/assets/css/main.css')); ?>">
	<!-- GOOGLE FONTS -->
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700" rel="stylesheet">
	<!-- ICONS -->
	<link rel="apple-touch-icon" sizes="76x76" href="<?php echo e(asset('Klorofil/assets/img/apple-icon.png')); ?>">
	<link rel="icon" type="image/png" sizes="96x96" href="<?php echo e(asset('Klorofil/assets/img/favicon.png')); ?>">
</head>

<body>
	<!-- WRAPPER -->
	<div id="wrapper">
		<!-- NAVBAR -->
        <?php echo $__env->make('layouts.inc._navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<!-- END NAVBAR -->
        <!-- LEFT SIDEBAR -->
        <?php echo $__env->make('layouts.inc._sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<!-- END LEFT SIDEBAR -->
		<!-- MAIN -->
        <?php echo $__env->yieldContent('konten'); ?>
		<!-- END MAIN -->
		<!-- <div class="main">
			<div class="main-content">
	            <div class="container-fluid">
	                <div class="row">
	                    <div class="col-md-12">
	                    	<div class="panel">
								<div class="panel-heading">
		                           	<h3 class="panel-title">Product</h3>
									    <div class="content">
									      	<div class="container-fluid">
									        	<div class="row">
									          		<div class="col-lg-6">
											            <div class="card">
											              	<div class="card-body">
											                <h5 class="card-title">Product_1</h5>
											                

											                <p class="card-text">
											                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer at sem risus. Fusce tempor metus nisl, vel malesuada sem malesuada porta.
											                </p>

											                <a href="#" class="card-link">Card link</a>
											              	</div>
											            </div>
										          	</div>
										        </div>
										    </div>
										</div>
									</div>
			                    </div>
			                </div>
			            </div>
			        </div>
        		</div> -->
			<footer>
				<div class="container-fluid">
					<p class="copyright">&copy; 2021 Kelompok Tupai</p>
				</div>
			</footer>
		</div>
	<!-- END WRAPPER -->
	<!-- Javascript -->
	<script src="<?php echo e(asset('Klorofil/assets/vendor/jquery/jquery.min.js')); ?>"></script>
	<script src="<?php echo e(asset('Klorofil/assets/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('Klorofil/assets/vendor/jquery-slimscroll/jquery.slimscroll.min.js')); ?>"></script>
	<script src="<?php echo e(asset('Klorofil/assets/scripts/klorofil-common.js')); ?>"></script>
</body>
</html>