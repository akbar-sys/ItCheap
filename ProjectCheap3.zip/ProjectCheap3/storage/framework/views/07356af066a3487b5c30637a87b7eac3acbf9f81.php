<?php $__env->startSection('konten'); ?>
    <div class="main">
        <div class="main-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="panel">
                            <form action="/pengajar/<?php echo e($pengajar->id); ?>/update" method="POST">
                            <?php echo e(csrf_field()); ?>

                                    <div class="mb-3">
                                        <label class="form-label">Nama</label>
                                        <input name="nama_pengajar" type="text" class="form-control" placeholder="Nama" value="<?php echo e($pengajar->nama_pengajar); ?>">
                                    </div>
                                    <div class="mb-3">
                                            <label class="form-label">Umur</label>
                                            <input name="umur" type="number" class="form-control" placeholder="Umur" value="<?php echo e($pengajar->umur); ?>">
                                    </div>
                                    <div class="mb-3">
                                            <label class="form-label">Alat Musik</label>
                                            <input name="alat_musik" type="text" class="form-control" placeholder="Alat Musik" value="<?php echo e($pengajar->alat_musik); ?>">
                                    </div>
                                    </div>
                                    <div class="modal-footer">
                                    <a href="/pengajar" class='btn btn-secondary'>Close</a>
                                    <button type="submit" class="btn btn-primary">Update</button>
                            </form>
						    </div>
						</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>