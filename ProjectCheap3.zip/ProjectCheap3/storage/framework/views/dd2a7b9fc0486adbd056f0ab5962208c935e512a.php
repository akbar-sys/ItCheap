<?php $__env->startSection('konten'); ?>
    <div class="main">
        <div class="main-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                    <div class="panel">
								<div class="panel-heading">
                                    <h3 class="panel-title">Data Pengajar</h3>
                                    <div class="right">
                                        <button type="button" class="btn" data-toggle="modal" data-target="#exampleModal"><i class="lnr lnr-plus-circle"></i></button>
                                    </div>
								</div>
								<div class="panel-body">
									<table class="table table-hover">
										<thead>
											<tr>
                                                <th>Nama Pengajar</th>
                                                <th>Umur</th>
                                                <th>Alat Musik</th>
                                                <th colspan ="2">Action</th>
											</tr>
										</thead>
										<tbody>
                                        <?php $__currentLoopData = $data_pengajar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengajar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($pengajar->nama_pengajar); ?></td>
                                            <td><?php echo e($pengajar->umur); ?></td>
                                            <td><?php echo e($pengajar->alat_musik); ?></td>
                                            <td><a href="/pengajar/<?php echo e($pengajar->id); ?>/edit" class='btn btn-info btn-sm '>Edit</a></td>
                                            <td><a href="/pengajar/<?php echo e($pengajar->id); ?>/delete" class='btn btn-danger' onclick="return confirm('Data akan dihapus, anda yakin?')">Delete</a></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</tbody>
									</table>
								</div>
							</div>
                    </div>
                </div>
            </div>
        </div>
    </div>    

    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Data Pengajar</h5>
      </div>
      <div class="modal-body">
      <form action="/pengajar/create_pengajar" method="POST">
            <?php echo e(csrf_field()); ?>

            <div class="mb-3">
                <label class="form-label">Nama Pengajar</label>
                <input name="nama_pengajar" type="text" class="form-control" placeholder="Nama">
            </div>
            <div class="mb-3">
                <label class="form-label">Umur</label>
                <input name="umur" type="number" class="form-control" placeholder="Umur">
            </div>
            <div class="mb-3">
                <label class="form-label">Alat Musik</label>
                <input name="alat_musik" type="text" class="form-control" placeholder="Alat Musik">
            </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>