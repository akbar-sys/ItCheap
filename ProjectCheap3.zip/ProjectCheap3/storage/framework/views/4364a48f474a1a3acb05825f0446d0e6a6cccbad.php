<?php $__env->startSection('konten'); ?>
    <div class="main">
        <div class="main-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                    <div class="panel">
						<div class="panel-heading">
                           <h3 class="panel-title">Product</h3>
                             <div class="right">
                                  <button type="button" class="btn" data-toggle="modal" data-target="#exampleModal"><i class="lnr lnr-plus-circle"></i></button>
                              </div>
								</div>
								<div class="panel-body">
									<table class="table table-hover">
										<thead>
											<tr>
                                                <th>Nama Produk</th>
                                                <th>Deskripsi</th>
                                                <th>Harga</th>
                                                <th>E-Commerce</th>
                                                <th>URL</th>
                                                <th colspan ="2">Action</th>
											</tr>
										</thead>
										<tbody>
                                        <?php $__currentLoopData = $data_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($product->nama_produk); ?></td>
                                            <td><?php echo e($product->deskripsi); ?></td>
                                            <td><?php echo e($product->harga); ?></td>
                                            <td><?php echo e($product->ecommerce); ?></td>
                                            <td><?php echo e($product->url); ?></td>
                                            <td><a href="/produk/<?php echo e($product->id_produk); ?>/edit" class='btn btn-info btn-sm '>Edit</a></td>
                                            <td><a href="/produk/<?php echo e($product->id_produk); ?>/delete" class='btn btn-danger' onclick="return confirm('Data akan dihapus, anda yakin?')">Delete</a></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</tbody>
									</table>
								</div>
							</div>
                    </div>
                </div>
            </div>
        </div>
    </div>    

    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah Produk</h5>
      </div>
      <div class="modal-body">
      <form action="/produk/create" method="POST">
            <?php echo e(csrf_field()); ?>

            <div class="mb-3">
                <label class="form-label">Nama Produk</label>
                <input name="nama_produk" type="text" class="form-control" placeholder="Nama Produk">
            </div>
            <div class="mb-3">
                <label class="form-label">Deskripsi</label>
                <input name="deskripsi" type="text" class="form-control" placeholder="Deskripsi">
            </div>
            <div class="mb-3">
                <label class="form-label">Harga</label>
                <input name="harga" type="text" class="form-control" placeholder="Harga">
            </div>
            <div class="mb-3">
                <label class="form-label">E-Commerce</label>
                <input name="ecommerce" type="text" class="form-control" placeholder="E-Commerce">
            </div>
            <div class="mb-3">
                <label class="form-label">URL</label>
                <input name="url" type="text" class="form-control" placeholder="URL">
            </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>