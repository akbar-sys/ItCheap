<?php $__env->startSection('konten'); ?>
    <div class="main">
        <div class="main-content">
            <div class="container-fluid">
            <h1> Edit Data Produk</h2>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="panel">
                            <form action="/produk/<?php echo e($product->id_produk); ?>/update" method="POST">
                            <?php echo e(csrf_field()); ?>

                                    <div class="mb-3">
                                        <label class="form-label">Nama Produk</label>
                                        <input name="nama_produk" type="text" class="form-control" placeholder="Nama Produk" value="<?php echo e($product->nama_produk); ?>" >
                                    </div>
                                    <div class="mb-3">
                                            <label class="form-label">Deskripsi</label>
                                            <input name="deskripsi" type="text" class="form-control" placeholder="Deskripsi" value="<?php echo e($product->deskripsi); ?>">
                                    </div>
                                    <div class="mb-3">
                                            <label class="form-label">Harga</label>
                                            <input name="harga" type="text" class="form-control" placeholder="Harga" value="<?php echo e($product->harga); ?>">
                                    </div>
                                    <div class="mb-3">
                                            <label class="form-label">E-Commerce</label>
                                            <input name="ecommerce" type="text" class="form-control" placeholder="E-Commerce" value="<?php echo e($product->ecommerce); ?>">
                                    </div>
                                    <div class="mb-3">
                                            <label class="form-label">URL</label>
                                            <input name="url" type="text" class="form-control" placeholder="URL" value="<?php echo e($product->url); ?>" >
                                    </div>
                                    <div class="modal-footer">
                                    <a href="/produk" class='btn btn-secondary'>Close</a>
                                    <button type="submit" class="btn btn-primary">Update</button>
                            </form>
						    </div>
						</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>