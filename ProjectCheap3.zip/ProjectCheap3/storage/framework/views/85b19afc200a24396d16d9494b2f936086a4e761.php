<div id="sidebar-nav" class="sidebar">
			<div class="sidebar-scroll">
				<nav>
					<ul class="nav">
						<li><a href="/dashboard" class=""><i class="lnr lnr-home"></i> <span>Dashboard</span></a></li>
						<li><a href="/pengajar" class=""><i class="lnr lnr-user"></i> <span>Pengajar</span></a></li>
					</ul>
				</nav>
			</div>
		</div>