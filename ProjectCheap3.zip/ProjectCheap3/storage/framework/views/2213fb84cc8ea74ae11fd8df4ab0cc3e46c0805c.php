<?php $__env->startSection('konten'); ?>
<img src="\xampp\htdocs\ProjectWeb\public\Klorofil\assets\img\ItMusic_Logo.jpg">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>